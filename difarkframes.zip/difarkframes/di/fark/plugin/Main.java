package di.fark.plugin;

import org.bukkit.Bukkit;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener {
   public void onEnable() {
      this.saveDefaultConfig();
      Bukkit.getPluginManager().registerEvents(this, this);
   }

    @EventHandler
    public void onBlockClicked(PlayerInteractEntityEvent event) {
        if (event.getRightClicked().getType() == EntityType.ITEM_FRAME && event.getPlayer().isSneaking()) {
            if (!((org.bukkit.entity.ItemFrame) event.getRightClicked).getItem().isEmpty()) {
                if (!this.getConfig().getString("make-permission").isEmpty() &&
                        !event.getPlayer().hasPermission(this.getConfig().getString("make-permission"))) {
                    if (!this.getConfig().getString("no-permission-message").isEmpty()) {
                        event.getPlayer().sendMessage(this.getConfig().getString("no-permission-message"));
                    }
                    return;
                }
                
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        "execute positioned " + event.getRightClicked().getLocation().getBlockX() + " "
                                + event.getRightClicked().getLocation().getBlockY() + " "
                                + event.getRightClicked().getLocation().getBlockZ()
                                + " run data merge entity @e[type=item_frame,limit=1,sort=nearest] {Invisible:1}");
            }
        }
    }
      }

   }
}
